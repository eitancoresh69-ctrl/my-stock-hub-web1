import streamlit as st
def render_execution_engine():
    st.markdown('<div class="ai-card" style="border-right-color: #607d8b;"><b>⚙️ מנוע ביצוע לשוק האמיתי:</b> הגדרות התממשקות לברוקר עתידי.</div>', unsafe_allow_html=True)
    st.info("הדמיית פקודות: הבוט הוגדר להשתמש ב-Limit Orders בלבד כדי למנוע החלקת מחיר (Slippage) כשתחובר לחשבון אמיתי.")

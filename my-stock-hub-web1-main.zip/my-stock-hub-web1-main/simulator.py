# simulator.py
import streamlit as st
import pandas as pd

def render_value_agent(df_all):
    st.markdown('<div class="ai-card" style="border-right-color: #2e7d32;"><b>💼 סוכן השקעות ערך:</b> קונה מניות יציבות בנקודת כניסה טכנית.</div>', unsafe_allow_html=True)
    
    if 'val_cash_ils' not in st.session_state:
        st.session_state.val_cash_ils, st.session_state.val_portfolio = 5000.0, []
    if 'val_receipt' in st.session_state: st.info(st.session_state.val_receipt)

    usd_rate = 3.8 
    cash_usd = st.session_state.val_cash_ils / usd_rate
    port_value_usd = sum([p['Qty'] * (df_all[df_all['Symbol'] == p['Symbol']]['Price'].iloc[0] if p['Currency'] == "$" else (df_all[df_all['Symbol'] == p['Symbol']]['Price'].iloc[0] / 100) / usd_rate) for p in st.session_state.val_portfolio]) if st.session_state.val_portfolio else 0

    c1, c2, c3 = st.columns(3)
    c1.metric("💵 יתרת מזומן", f"₪{st.session_state.val_cash_ils:,.2f}")
    c2.metric("💼 שווי תיק", f"${port_value_usd:,.2f}")
    c3.metric("📈 תשואה פתוחה", f"{((port_value_usd / (5000 / usd_rate)) - 1) * 100 if port_value_usd > 0 else 0.0:.1f}%")

    if st.button("🚀 הפעל סוכן ערך"):
        if st.session_state.val_cash_ils > 100:
            if 'val_receipt' in st.session_state: del st.session_state.val_receipt
            gold_stocks = df_all[(df_all['Score'] >= 5) & (df_all['RSI'] > 35)]
            if not gold_stocks.empty:
                inv = cash_usd / len(gold_stocks)
                st.session_state.val_portfolio = [{"Symbol": r['Symbol'], "Currency": r['Currency'], "Buy_Price": r['PriceStr'], "Qty": round(inv / (r['Price'] if r['Currency']=="$" else (r['Price']/100)/usd_rate), 2)} for _, r in gold_stocks.iterrows()]
                st.session_state.val_cash_ils = 0
                st.rerun()

    if st.session_state.val_portfolio:
        if st.button("💸 סגור עסקאות והצג רווח/הפסד"):
            profit_ils = (port_value_usd * usd_rate) - 5000.0
            st.session_state.val_cash_ils, st.session_state.val_portfolio = 5000.0, []
            st.session_state.val_receipt = f"✅ התיק נסגר. סך רווח/הפסד נטו: ₪{profit_ils:.2f}"
            st.rerun()

def render_day_trade_agent(df_all):
    st.markdown('<div class="ai-card" style="border-right-color: #d32f2f;"><b>⚡ סוכן מסחר יומי:</b> פריצות RSI.</div>', unsafe_allow_html=True)
    
    if 'day_cash_ils' not in st.session_state:
        st.session_state.day_cash_ils, st.session_state.day_portfolio = 5000.0, []
    if 'day_receipt' in st.session_state: st.info(st.session_state.day_receipt)

    usd_rate = 3.8 
    cash_usd = st.session_state.day_cash_ils / usd_rate
    port_value_usd = sum([p['Qty'] * (df_all[df_all['Symbol'] == p['Symbol']]['Price'].iloc[0] if p['Currency'] == "$" else (df_all[df_all['Symbol'] == p['Symbol']]['Price'].iloc[0] / 100) / usd_rate) for p in st.session_state.day_portfolio]) if st.session_state.day_portfolio else 0

    c1, c2, c3 = st.columns(3)
    c1.metric("💵 מזומן", f"₪{st.session_state.day_cash_ils:,.2f}")
    c2.metric("💼 שווי פוזיציות", f"${port_value_usd:,.2f}")
    c3.metric("📈 תשואה פתוחה", f"{((port_value_usd / (5000 / usd_rate)) - 1) * 100 if port_value_usd > 0 else 0.0:.1f}%")

    if st.button("⚡ הפעל סוכן יומי"):
        if st.session_state.day_cash_ils > 100:
            if 'day_receipt' in st.session_state: del st.session_state.day_receipt
            stocks = df_all[(df_all['RSI'] < 40) | ((df_all['RSI'] > 65) & (df_all['Price'] > df_all['MA50']))].head(3)
            if not stocks.empty:
                inv = cash_usd / len(stocks)
                st.session_state.day_portfolio = [{"Symbol": r['Symbol'], "Currency": r['Currency'], "Buy_Price": r['PriceStr'], "Qty": round(inv / (r['Price'] if r['Currency']=="$" else (r['Price']/100)/usd_rate), 2)} for _, r in stocks.iterrows()]
                st.session_state.day_cash_ils = 0
                st.rerun()

    if st.session_state.day_portfolio:
        if st.button("💸 סגור טרייד יומי והצג רווח/הפסד"):
            profit_ils = (port_value_usd * usd_rate) - 5000.0
            st.session_state.day_cash_ils, st.session_state.day_portfolio = 5000.0, []
            st.session_state.day_receipt = f"⚡ הטרייד נסגר. סך רווח/הפסד יומי: ₪{profit_ils:.2f}"
            st.rerun()

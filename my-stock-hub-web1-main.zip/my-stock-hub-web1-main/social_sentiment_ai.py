import streamlit as st
def render_social_intelligence():
    st.markdown('<div class="ai-card" style="border-right-color: #03a9f4;"><b>🐦 מודיעין רשתות חברתיות:</b> סריקת הייפ מוקדם.</div>', unsafe_allow_html=True)
    st.info("🟢 מגמה נוכחית: ה-AI מזהה תנועת סנטימנט חיובית במניות השבבים (NVDA) בפורומים המקצועיים ב-24 השעות האחרונות.")
